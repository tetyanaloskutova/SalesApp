from django.contrib import admin
from .models import RiskField

admin.site.register(RiskField)
"""
from django.shortcuts import render

from rest_framework import generics
from .serializers import RiskTypeSerializer
from .models import RiskType

class CreateView(generics.ListCreateAPIView):
    queryset = RiskType.objects.all()
    serializer_class = RiskTypeSerializer

    def perform_create(self, serializer):
        serializer.save()
		
		
class DetailsView(generics.RetrieveUpdateDestroyAPIView):

    queryset = RiskType.objects.all()
    serializer_class = RiskTypeSerializer
	
"""	
	
from django.contrib.auth.models import User
from rest_framework import generics
from rest_framework import viewsets
from rest_framework.decorators import list_route, detail_route
from rest_framework.response import Response

from .serializers import RiskTypeSerializer, RiskFieldSerializer, UserSerializer
from .permissions import IsStaffOrOwner
from risktypes import models
import sys
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.reverse import reverse


@api_view(['GET'])
def api_root(request, format=None):
	return Response({
		'users': reverse('user-detail', request=request, format=format),
		'risktypes': reverse('risktype-list', request=request, format=format)
	})
 	
	
class RiskFieldViewSet(viewsets.ModelViewSet):
	serializer_class = RiskFieldSerializer
	permission_classes = (IsStaffOrOwner,)
	queryset = models.RiskField.objects.all()
	
	"""def get_queryset(self):
		if self.request.user.is_superuser:
			return models.RiskField.objects.all()
		else:
			return self.request.user.user_riskfield.all()
	"""
	#def perform_create(self, serializer):
	#	serializer.save(user_riskfield = self.request.user)
	
	
		

class RiskTypeViewSet(viewsets.ModelViewSet):
	serializer_class = RiskTypeSerializer
	permission_classes = (IsStaffOrOwner,)
	queryset = models.RiskType.objects.all()
	
	"""def get_queryset(self):
		if self.request.user.is_superuser:
			return models.RiskType.objects.all()
		else:
			return self.request.user.user_risktype.all()
	"""
	#def perform_create(self, serializer):
	#	serializer.save(user_risktype = self.request.user)
		

	# The detail_route allows to see all the riskfields of a risk type
	# with the following URL: /risktypes/risktype/(?P<pk>\d+)/riskfields

	@detail_route()
	def riskfields(self, request, pk):
		#print("Goodbye cruel world!" + pk, file=sys.stderr)
		risktype = models.RiskType.objects.get(pk=pk)
		riskfields = risktype.risktype_riskfield.all()
		serializer = RiskFieldSerializer(riskfields)
		return Response(serializer.data)


class UserList(generics.ListAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer


class UserDetail(generics.RetrieveAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer	
from django.apps import AppConfig


class RisktypesConfig(AppConfig):
    name = 'risktypes'

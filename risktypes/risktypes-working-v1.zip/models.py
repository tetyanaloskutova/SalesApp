
from django.db import models
from django.contrib.auth.models import User

class RiskType(models.Model):
	user_risktype = models.ForeignKey(User, related_name="+", on_delete = models.CASCADE,)
	# other fields
	name = models.CharField(max_length=256)
	description = models.TextField()
	

	class Meta:
		verbose_name = 'RiskType'
		verbose_name_plural = 'RiskTypes'

class RiskField(models.Model):
	user_riskfield = models.ForeignKey(User, related_name="+", on_delete = models.CASCADE,)
	risktype = models.ForeignKey(RiskType, related_name="risktype_riskfield", on_delete = models.CASCADE,)
	# other fields
	name = models.CharField(max_length=256)
	description = models.TextField()
	

	class Meta:
		verbose_name = 'RiskField'
		verbose_name_plural = 'RiskFields'

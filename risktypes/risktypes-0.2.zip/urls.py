"""

from django.urls import path, re_path
from rest_framework.urlpatterns import format_suffix_patterns
from .views import CreateView
from .views import DetailsView

urlpatterns = {
    path(r'', CreateView.as_view(), name="create"),
	re_path(r'(?P<pk>[0-9]+)/$',
        DetailsView.as_view(), name="details"),
	#path('admin/', admin.site.urls),
}

urlpatterns = format_suffix_patterns(urlpatterns)
"""


from django.conf.urls import url, include, re_path
from rest_framework.routers import DefaultRouter

from . import views

router = DefaultRouter()
router.register(r'riskfields', views.RiskFieldViewSet) #, base_name='risktypes'
router.register(r'risktype', views.RiskTypeViewSet)

urlpatterns = [
    url(r'^', include(router.urls)),
    url(r'^api-auth/', include('rest_framework.urls', namespace='rest_framework')),
	#url(r'^users/$', views.UserList.as_view()),
	#url(r'^users/(?P<pk>[0-9]+)/$', views.UserDetail.as_view()),
	url(r'^users/$',  views.UserList.as_view(),name='user-list'),
    url(r'^users/(?P<pk>[0-9]+)/$', views.UserDetail.as_view(), name='user-detail'),
	url(r'^riskfields/$',  views.RiskFieldList.as_view(), name="riskfield-list"),
	
	url(r'^riskfields/$',  views.RiskFieldList.as_view(), name="riskfield-list"),
]


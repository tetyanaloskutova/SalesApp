"""
The questions of deletion are often dependent on the insurer's business rules. Typically, a risk type should not be edited once assigned to a product.
For simplicity, I skip soft-delete functionality and authentication/authorization


from django.db import models
from django.utils import timezone
from django.core.validators import MinValueValidator, MaxValueValidator
from django.contrib.auth.models import User


class RiskType(models.Model):
	author = 'daana'#models.ForeignKey(User, on_delete=models.CASCADE,)
	
	name = models.CharField(max_length=256)
	description = models.TextField()
	# in a full model, organisation is autopopulated based on the user (in extreme cases, technical support might be requested to edit 
	organization = models.TextField()
	created_date = models.DateTimeField(default=timezone.now)
	timezone.make_aware(timezone.datetime.max, timezone.get_default_timezone())
	deleted_date = models.DateTimeField(default=timezone.datetime.max)
	
	
	#def soft_delete(self):
	#	self.deleted_date = timezone.now
	#	self.save()


class RiskField(models.Model):
	
	#using default 'id'
	name = models.CharField(max_length=256)
	description = models.TextField()
	TEXT = 1
	NUMBER = 2
	DATE = 3
	ENUM = 4
	
	TYPE_CHOICES = (
		(TEXT, 'Text'),
		(NUMBER, 'Number'),
		(DATE, 'Date'),	
		(ENUM, 'Enum'),	
	)
	type = models.CharField(max_length=256,choices=TYPE_CHOICES,
		default=TEXT)
    
	length = models.IntegerField( validators=[MaxValueValidator(1e65)])
	len_decim = models.IntegerField( validators=[MaxValueValidator(1e30)])
	created_date = models.DateTimeField(default=timezone.now)
	
	def publish(self):
		self.published_date = timezone.now()
		self.save()

	def __str__(self):
		return self.name
	
	# TODO: delete		
	def __init__(self,name, type, length = 256, len_decim = 0):
		self.name = name
		self.type = type
		self.length = length
		self.len_decim = len_decim
		
	
	
class RiskTypeFieldMap():
	risktype = models.ForeignKey('RiskType', on_delete=models.CASCADE,)
	risktype = models.ForeignKey('RiskField', on_delete=models.CASCADE,)
	author = models.ForeignKey('auth.User', on_delete=models.CASCADE,)
	created_date = models.DateTimeField(default=timezone.now)
	# if deleted, the mapping is preserved for historical analysis but not used for current
	deleted_date = models.DateTimeField(default=timezone.datetime.max)

"""	
# RiskFields have a FK to RiskType. RiskEnum is a list in RiskField

from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator, MaxValueValidator

		
class RiskType(models.Model):
	#user = models.ForeignKey(User, related_name="user_risktype", on_delete=models.CASCADE,)
	# other fields: in the real world model, there might be more fields, like organisation, date_deleted, is_valid, etc. 
	name = models.CharField(max_length=256)
	description = models.TextField()
	
	class Meta:
		verbose_name = 'RiskType'
		verbose_name_plural = 'RiskTypes'

class RiskField(models.Model):
	#user = models.ForeignKey(User, related_name="user_riskfield", on_delete=models.CASCADE,)
	parent_risktype = models.ForeignKey(RiskType, related_name="risktype_riskfields", on_delete=models.CASCADE,)
	
	name = models.CharField(max_length=256)
	description = models.TextField()
	TEXT = '1'
	NUMBER = '2'
	DATE = '3'
	ENUM = '4'
	
	TYPE_CHOICES = (
		(TEXT, 'Text'),
		(NUMBER, 'Number'),
		(DATE, 'Date'),	
		(ENUM, 'Enum'),	
	)
	type = models.CharField(max_length=1,choices=TYPE_CHOICES,
		default=TEXT)
    
	length = models.IntegerField( validators=[MaxValueValidator(1e65)])
	len_decim = models.IntegerField( validators=[MaxValueValidator(1e30)])
	enumlist = models.TextField()
	
	class Meta:
		verbose_name = 'RiskField'
		verbose_name_plural = 'RiskFields'

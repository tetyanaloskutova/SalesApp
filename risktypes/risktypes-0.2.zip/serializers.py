"""from rest_framework import serializers
from .models import RiskType

class RiskTypeSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = RiskType
        fields = ('id', 'author','name', 'description', 'organization','created_date')
        read_only_fields = ('author', 'created_date')
"""

from django.contrib.auth.models import User
from rest_framework import serializers
from risktypes import models
import sys

class UserSerializer(serializers.ModelSerializer):
	#risktypes = serializers.PrimaryKeyRelatedField(many=True, queryset=models.RiskType.objects.all())
	#url = serializers.HyperlinkedIdentityField(view_name="user-detail")

	class Meta:
		model = User
		#fields = ('url', 'username')
		fields = '__all__'# ('id', 'username', 'risktypes')
		

class RiskFieldSerializer(serializers.HyperlinkedModelSerializer):
	#user_riskfield = serializers.HyperlinkedRelatedField(view_name="user-detail", read_only=True)
	#user_riskfield = serializers.ReadOnlyField(source='user_riskfield.username')
	#user_riskfield = UserSerializer()
	
	parent_risktype = serializers.HyperlinkedRelatedField(view_name='risktype-detail', read_only=True)
	enumlist = serializers.CharField()
	description_html = serializers.CharField(source='enumlist', read_only=True)
	#enum = serializers.CharField()

	class Meta:
		model = models.RiskField
		fields = '__all__'# ('id', 'url', 'user_riskfield', 'name', 'description', 'type', 'length', 'len_decim', 'enum', 'enumlist')
		
	def transform_description_html(self, obj, value):
		from django.contrib.markup.templatetags.markup import markdown
		return markdown(value) # or other transform
	
	def get_enum(self, obj):
		print("Goodbye cruel world!" , file=sys.stderr)
		return "Goodbye cruel world!"
		
class RiskTypeSerializer(serializers.HyperlinkedModelSerializer):
	#risktype_riskfields = serializers.HyperlinkedRelatedField(many=True, required=False, view_name='riskfield-list', read_only = 'True')
	risktype_riskfields = serializers.HyperlinkedRelatedField(many=True, required=False, view_name='riskfield-detail', read_only = 'True')
	
	#user_risktype = serializers.HyperlinkedRelatedField(view_name="user-detail", read_only=True)
	#user_risktype = serializers.ReadOnlyField(source='user_risktype.username')
	#user_risktype = UserSerializer()
	
	class Meta:
		model = models.RiskType
		fields = '__all__'# ('id', 'url', 'user_risktype', 'risktype_riskfield', 'name', 'description')

